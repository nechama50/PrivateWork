package com.st10090931.nechamaberman.opsc7311_icetask1_calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText

class   MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textBoxOne = findViewById<EditText>(R.id.Number);
        val textBoxTwo = findViewById<EditText>(R.id.Number2);
    }
}